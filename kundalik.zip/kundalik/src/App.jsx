import Navbar from "./Navbar/Navbar/Navbar";
import Nav from "./Navbar/Nav/Nav";
import "./App.scss";


function App() {
  return (
    <div>
      <Navbar />
      <Nav />
    </div>
  );
}

export default App;
