import { NavLink } from "react-router-dom";
import "./Nav.scss"
const Nav = () => {
  return (
  <div className="katta">
      <div className="talim">
      <div className="talim1">
        <NavLink to={"/talim"}>TA'LIM</NavLink>
        <NavLink to={"/profil"}>PROFIL</NavLink>
        <NavLink to={"/malumot"}>MULOQAT</NavLink>
        <NavLink>ILOVALAR</NavLink>
      </div>
      <NavLink>MENING BALLARIM</NavLink>
    </div>
  </div>
  );
};
export default Nav;
