import "./LoginBar.scss";
import { NavLink,Link } from "react-router-dom";
const LoginBar = () => {
  return (
    <div className="tashkilot">
      <div className="imkoniyatlar">
        <img
          className="log"
          src="https://idum.uz/wp-content/uploads/2020/07/kundalik_600.jpg"
          alt=""
        />

        <div className="hamkorlik">
          <NavLink className="box">Tashkilot</NavLink>
          <h4>|</h4>
          <NavLink className="box">Imkoniyatlar</NavLink>
          <h4>|</h4>
          <NavLink className="box">Hamkorlarga</NavLink>
          <h4>|</h4>
          <NavLink className="box">Yordam</NavLink>
        </div>

        <div className="yordam">
          <select name="" id="uzb">
            <option value="uz">O'zb</option>
            <option value="ru">Рус</option>
          </select>
          <Link to={"/talim"} className="kirish">Kirish</Link>
          <button className="ulash">Tashkilotni ulash</button>
        </div>
      </div>
    </div>
  );
};
export default LoginBar;
