import React, { Suspense } from "react";
import ReactDOM from "react-dom/client";
import "./index.scss";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { lazy } from "react";
import Talim from "./Pages/Talim/Talim.jsx";
import Profil from "./Pages/Profil/Profil.jsx";
import Malumot from "./Pages/Malumot/Malumot.jsx";


const App = lazy(() => import("./App.jsx"));
const Login = lazy(() => import("./Pages/Login/Login.jsx"));



const router = createBrowserRouter([
  {
    path:"/",
  element:<App/>
  },
  {
    path:"/login",
    element:<Login/>
  },
  {
    path:"/talim",
    element:<Talim/>
  },
  {
    path:"/profil",
    element:<Profil/>
  },
  {
    path:"/malumot",
    element:<Malumot/>
  }
])

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Suspense fallback={<p>...loading</p>}>
      <RouterProvider router={router}></RouterProvider>
    </Suspense>
  </React.StrictMode>
);
