import { Link } from "react-router-dom"
import "./Talim.scss"
const TalimBar = ()=>{
    return(
     <div className="talim1">
           <div className="talimBar">
            <div className="talimBar_bar">
            <Link>Mening maktabim</Link>
            <Link>Mening sinfim</Link>
            <Link>Kundalik</Link>
            <Link>Dars jadvali</Link>
            <Link>Uy vazifasi</Link>
            </div>      
        </div>
     </div>
    )
}
export default TalimBar