import { Link } from "react-router-dom"
import "./ProfilBar.scss"
const ProfilBar = ()=>{
    return(
        <div className="profil">
            <div className="profil_bar2">
                <div className="profil_bar_bar1">
                    <Link>Xabarlar</Link>
                    <Link>Fayllar</Link>
                </div>
            </div>
        </div>
    )
}
export default ProfilBar