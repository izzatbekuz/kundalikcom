import "./Profilbottom.scss"
import ObBotton from "../ObBottom/ObBotton"
import { Link } from "react-router-dom"
const Profilbottom = () => {
    return (
        <div className="pro">
            <div className="pro_develop">
                <div className="del">

                    <div className="del_pro">
                        <div className="link">
                            <h4>Aloqa uchun ma'lumot</h4>
                            <Link className="orgarish">O'zgartirish</Link>
                        </div>
                        <div className="bottom1">
                            <h3>Elektron pochta</h3>
                            <Link>izzatbekm22@gmail.com</Link>
                        </div>
                    </div>



                    <div className="devor">
                        <h3>Devor</h3>
                        <div>
                            <input className="sharh" type="text" placeholder="Sharh yozing" />
                        </div>
                    </div>


                </div>
                <div className="fayllar">
                    <div>
                        <h3>Fayllar</h3>
                    </div>
                    <div className="bottom2">
                        <h2>Sizda fayllar yo'q</h2>
                    </div>
                </div>
                <div className="pastki_chizik"></div>
            <ObBotton/>
            </div>
        </div>
    )
}
export default Profilbottom