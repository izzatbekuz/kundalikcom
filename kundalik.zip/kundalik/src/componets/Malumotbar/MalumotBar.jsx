import ObBotton from "../ObBottom/ObBotton"
import Profilbottom from "../Profilbottom/Profilbottom"
import "./MalumotBar.scss"
import { Link } from "react-router-dom"
const MalumotBar = () => {
    return (
        <div className="topTarmoq">
            <div className="topTarmoqq">
                <h1>Tarmoqlar</h1>
                <div className="spann">
                    <Link className="linkk">Joriy</Link>
                    <Link className="linkkkk">Arxivdagilar</Link>
                </div>
                <div className="kattaTarmoimg">
                    <img className="imgTarmoq" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLOKTsvHnhCJTbAZZQFztTOfOMmzySMjP7zZTSjYfRNg&s" alt="" />
                    <div>
                        <h2>“Humans”dan 100 foizlik keshbek bilan veb-obunani</h2>
                        <p>1 ta ishtirokchi</p>
                    </div>
                </div>
                <div className="kattaTarmoimg">
                    <img className="imgTarmoq" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9bJ_s39H8lkwEsRhuD1u4jxDImDHcAZsrbQ23Fg0SDA&s" alt="" />
                    <div>
                        <h2>Yaxshi o‘qiganlik uchun PRO obunasini oling!</h2>
                        <p>1 ta ishtirokchi</p>
                    </div>
                </div>
                <div className="kattaTarmoimg">
                    <img className="imgTarmoq" src="https://an1.kundalik.com/get.aspx/39/b25bfd345af74165ac7d7489b8478c7e.m.png?d=20200330081337" alt="" />
                    <div>
                        <h2>Дистанционное образование</h2>
                        <p> Уважаемые пользователи!Команда Kundalik.com предлагает вашему вниманию сеть <br /> «Дистанционное образова... <br />3591 ishtirokchi</p>
                    </div>
                </div>
                <div className="kattaTarmoimg">
                    <img className="imgTarmoq" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9bJ_s39H8lkwEsRhuD1u4jxDImDHcAZsrbQ23Fg0SDA&s" alt="" />
                    <div>
                        <h2>Получай PRO- подписку за хорошую учебу!</h2>
                        <p>1 ta ishtirokchi</p>
                    </div>
                </div>
                <div className="kattaTarmoimg">
                    <img className="imgTarmoq" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLOKTsvHnhCJTbAZZQFztTOfOMmzySMjP7zZTSjYfRNg&s" alt="" />
                    <div>
                        <h2>Получи веб-подписку от Humans за 0 сумм!</h2>
                        <p>1 ta ishtirokchi</p>
                    </div>
                </div>
                <div className="kattaTarmoimg">
                    <img className="imgTarmoq" src="https://an1.kundalik.com/get.aspx/39/b25bfd345af74165ac7d7489b8478c7e.m.png?d=20200330081337" alt="" />
                    <div>
                        <h2>Система «Kundalik» / «Kundalik» тизими</h2>
                        <p>Официальное сообщество. <br />2553 ishtirokchini</p>
                    </div>
                </div>
                <div className="chiziq"></div>
                <ObBotton />
            </div>
        </div>
    )
}
export default MalumotBar