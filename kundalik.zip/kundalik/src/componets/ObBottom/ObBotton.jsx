import "./ObBotton.scss"
import { Link } from "react-router-dom"
import FacebookIcon from '@mui/icons-material/Facebook';
import InstagramIcon from '@mui/icons-material/Instagram';
import TelegramIcon from '@mui/icons-material/Telegram';
import YouTubeIcon from '@mui/icons-material/YouTube';
const ObBotton=()=>{
    return(
        <div className="ob">
            <div className="ob1">
                <div className="obbottom">
                    <div className="obbottom1">
                    <Link>Loyha haqida</Link>
                    <Link>Yangiliklar</Link>
                    <Link>Yordam</Link>
                    <Link>Aloqa ma'lumotlari</Link>
                    </div>
                    <div>
                        <h4>Mobil ilova</h4>
                    </div>
                    <Link>Fodalanuvchi shartnomasi</Link>
                </div>
                <div className="iconins">
                    <div>
                    <FacebookIcon className="insta"/>
                    <InstagramIcon className="insta"/>
                    <TelegramIcon className="insta"/>
                    <YouTubeIcon className="insta"/>
                    </div>
                    <div className="imglogo">
                        <img className="appleLogo" src="https://1000logos.net/wp-content/uploads/2020/08/apple-app-store-logo.jpg" alt="" />
                        <img className="googleplayLogo" src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png" alt="" />
                    </div>
                </div>
            </div>
        </div>
    )
}
export default ObBotton