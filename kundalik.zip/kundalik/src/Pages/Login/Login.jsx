import LoginBar from "../../Navbar/LoginBar/LoginBar.jsx";
import "./Login.scss";
import { NavLink } from "react-router-dom";
import QuestionMarkIcon from "@mui/icons-material/QuestionMark";
import FacebookIcon from "@mui/icons-material/Facebook";
import InstagramIcon from "@mui/icons-material/Instagram";
import TelegramIcon from "@mui/icons-material/Telegram";
import YouTubeIcon from "@mui/icons-material/YouTube";
const Login = () => {
  return (
    <div>
      <LoginBar />



      <div className="main">
        <div className="main1">
          <h1>Kirish eMakatab</h1>
          <div>
            <NavLink>tizimdan royhatdan o'tganmisiz ?</NavLink>
          </div>
        </div>


        <div className="main2">
          <label htmlFor="">Login</label>
          <input className="login" type="text" />
          <label className="label" htmlFor="">
            Password
          </label>
          <input className="password" type="password" />
          <button className="btn">Tizimga kiring</button>
        </div>


        <div className="main3">
          <QuestionMarkIcon className="soroq" />
          <h3>
            Login yoki parolni unutdingizmi? <NavLink>Loginni tiklash</NavLink>.
          </h3>
        </div>
      </div>



      <div className="footer">
        <div className="foooter1">
          <h1>Tashkilot haqida</h1>
          <h3>Biz haqimizda</h3>
          <h3>Bloqa uchun ma'lumotlar</h3>
          <FacebookIcon />
          <InstagramIcon />
          <TelegramIcon />
          <YouTubeIcon />
        </div>
        <div className="foooter1">
          <h1>imkoniyatlar</h1>
          <h3>O'qituvchilarga</h3>
          <h3>Ota-onalarga</h3>
          <h3>O'quvchilarga</h3>
          <h3>Davlat organlariga</h3>
        </div>
        <div className="foooter1">
          <h1>Hamkorlarga</h1>
          <h3>Hamkorlik dasturlari</h3>
        </div>
        <div className="foooter1">
          <h1>Qollab-quvvatlash</h1>
          <h3>Qollab-quvvatlash xizmati partali</h3>
          <button className="btn1">Tashkilotni ulash</button>
        </div>
      </div>
    </div>
  );
};
export default Login;
