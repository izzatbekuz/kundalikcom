import Nav from "../../Navbar/Nav/Nav"
import Navbar from "../../Navbar/Navbar/Navbar"
import ProfilBar from "../../componets/ProfilBar/ProfilBar"
import { Link } from "react-router-dom"
import "./Profil.scss"
import Profilbottom from "../../componets/Profilbottom/Profilbottom"

const Profil = () => {
    return (
        <div>
            <Navbar />
            <Nav />
            <ProfilBar />

            <div className="img_bar">
                <div className="img_bar_center">
                    <div className="img_bar_center_ob">
                        <img
                            className="profil_rasm"
                            src="https://cdn-icons-png.flaticon.com/512/1077/1077114.png"
                            alt=""
                        />
                        <div className="img_bar_center_ob_text">
                            <h1>Farhodov Izzatbek Farhod og'li</h1>
                            <p>oxirgi kirish: no aniq</p>
                            <div className="img_bar_center_ob_text_malumot">
                                <div className="img_bar_center_ob_text_malumot1">
                                    <h3>Maktab:</h3>
                                    <h3>Qarindoshlar:</h3>
                                    <h3>Tug'ulgan kuni:</h3>
                                </div>
                                <div className="img_bar_center_ob_text_malumot2">
                                    <h3>195-IDUM(9Ж)</h3>
                                    <h3>Гўзал Аманбаевна Матяқубова</h3>
                                    <h3>2 iyun</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="img_bar_profil_btn">
                        <div className="img_bar_profil_btn1">
                            <Link className="profil_btn">Profil</Link>
                            <Link className="profil_btn">Yutuqlar</Link>
                            <Link className="profil_btn">Fayllar</Link>
                        </div>
                        <div className="buttom"></div>
                    </div>
                </div>
            </div>
            <Profilbottom/>
        </div>
    )
}
export default Profil