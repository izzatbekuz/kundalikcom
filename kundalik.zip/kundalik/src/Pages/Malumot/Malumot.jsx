import "./Malumot.scss"
import Navbar from "../../Navbar/Navbar/Navbar"
import Nav from "../../Navbar/Nav/Nav"
import { Link } from "react-router-dom"
import MalumotBar from "../../componets/Malumotbar/MalumotBar"

const Malumot = () => {
    return (
        <div>
            <Navbar />
            <Nav />
            <div className="tar">
                <div className="tarmo">
                    <Link>Tarmoqlar</Link>
                </div>
            </div>
            <MalumotBar/>
        </div>
    )
}
export default Malumot