import LoginBar from "../../Navbar/LoginBar/LoginBar"
import Nav from "../../Navbar/Nav/Nav"
import Navbar from "../../Navbar/Navbar/Navbar"
import ObBotton from "../../componets/ObBottom/ObBotton"
import TalimBar from "../../componets/Talimbar/Talim"

const Talim =()=>{
    return(
        <div>
            <Navbar/>
            <Nav/>
            <TalimBar/>
        </div>
    )
}
export default Talim